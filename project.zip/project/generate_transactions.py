import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# --- Configuration ---
NUM_TRANSACTIONS = 10000  # Number of transactions to generate
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2023, 12, 31)
ACCOUNT_PREFIX = "ACC"
TRANSACTION_TYPES = ['Deposit', 'Withdrawal', 'Transfer', 'Online Purchase', 'Bill Payment', 'Loan Repayment']
CURRENCIES = ['USD', 'EUR', 'GBP', 'INR', 'CAD', 'AUD']
BANKS = ['Bank A', 'Bank B', 'Bank C', 'International Bank X', 'International Bank Y']
LOCATIONS_DOMESTIC = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Miami', 'Bengaluru', 'Mumbai', 'Delhi']
LOCATIONS_INTERNATIONAL_NORMAL = ['London', 'Paris', 'Berlin', 'Tokyo', 'Sydney', 'Toronto']
LOCATIONS_INTERNATIONAL_RISK = ['Zurich', 'Dubai', 'Panama City', 'Cayman Islands', 'Singapore'] # For potential 'high-risk' simulation

# --- Helper Functions ---
def generate_account_id():
    return f"{ACCOUNT_PREFIX}{random.randint(1000000000, 9999999999)}"

def generate_timestamp(start, end):
    return start + (end - start) * random.random()

def generate_amount(min_val, max_val, decimal_places=2):
    return round(random.uniform(min_val, max_val), decimal_places)

# --- Data Generation ---
data = []
account_pool = [generate_account_id() for _ in range(2000)] # Pool of accounts

for i in range(NUM_TRANSACTIONS):
    transaction_id = f"TXN{i + 1:07d}"
    timestamp = generate_timestamp(START_DATE, END_DATE)
    sender_account_id = random.choice(account_pool)
    receiver_account_id = random.choice(account_pool)
    while sender_account_id == receiver_account_id: # Ensure sender and receiver are different
        receiver_account_id = random.choice(account_pool)

    transaction_type = random.choice(TRANSACTION_TYPES)
    amount = generate_amount(10, 50000) # General range

    currency = random.choice(CURRENCIES)
    sender_bank = random.choice(BANKS)
    receiver_bank = random.choice(BANKS)

    # Simulate location logic
    is_international = random.random() < 0.2 # 20% chance of international transaction
    if is_international:
        if random.random() < 0.1: # 10% of international are from 'risk' locations
            location = random.choice(LOCATIONS_INTERNATIONAL_RISK)
        else:
            location = random.choice(LOCATIONS_INTERNATIONAL_NORMAL)
    else:
        location = random.choice(LOCATIONS_DOMESTIC)

    transaction_purpose = f"Payment for {random.choice(['services', 'goods', 'investment', 'loan', 'family'])}"

    is_suspicious = False # Default to False

    # --- Injecting Suspicious Transactions ---
    if i % 100 == 0: # Every 100th transaction - large, round sum
        amount = random.choice([10000, 25000, 50000, 9999.99, 49999.99])
        transaction_type = 'Transfer'
        sender_bank = 'International Bank X'
        receiver_bank = 'Bank A'
        location = random.choice(LOCATIONS_INTERNATIONAL_RISK)
        transaction_purpose = "Investment Transfer"
        is_suspicious = True
    elif i % 150 == 0: # Frequent small transactions just below threshold (e.g., $10k threshold)
        num_small_txns = random.randint(2, 5)
        for _ in range(num_small_txns):
            amount = generate_amount(9000, 9999) # Below threshold
            temp_timestamp = timestamp + timedelta(minutes=random.randint(1, 60))
            data.append([
                f"TXN_S{len(data)+1:05d}", temp_timestamp, sender_account_id,
                random.choice(account_pool), 'Deposit', amount, currency,
                sender_bank, 'Bank A', location, 'Cash Deposit', True
            ])
        amount = generate_amount(1000, 5000) # One regular txn to follow
        is_suspicious = True # Mark the original trigger as suspicious
    elif i % 200 == 0: # Unusual time and large amount
        timestamp = generate_timestamp(datetime(2023,1,1,23,0,0), datetime(2023,12,31,5,0,0)) # Late night/early morning
        amount = generate_amount(75000, 200000)
        transaction_type = 'Transfer'
        is_suspicious = True
    elif i % 250 == 0: # Rapid movement of funds (layering)
        intermediary_account = generate_account_id()
        # Sender to intermediary
        data.append([
            f"TXN_L{len(data)+1:05d}", timestamp, sender_account_id, intermediary_account,
            'Transfer', amount, currency, sender_bank, 'Bank A', location, 'Intermediary transfer', True
        ])
        # Intermediary to receiver
        data.append([
            f"TXN_L{len(data)+2:05d}", timestamp + timedelta(minutes=random.randint(5, 30)), intermediary_account, receiver_account_id,
            'Transfer', amount, currency, 'Bank A', receiver_bank, location, 'Final transfer', True
        ])
        is_suspicious = True # Mark the original trigger as suspicious

    data.append([
        transaction_id, timestamp, sender_account_id, receiver_account_id,
        transaction_type, amount, currency, sender_bank, receiver_bank,
        location, transaction_purpose, is_suspicious
    ])

# Create DataFrame
df = pd.DataFrame(data, columns=[
    'transaction_id', 'timestamp', 'sender_account_id', 'receiver_account_id',
    'transaction_type', 'amount', 'currency', 'sender_bank', 'receiver_bank',
    'location', 'transaction_purpose', 'is_suspicious'
])

# Sort by timestamp for better time-series analysis
df = df.sort_values(by='timestamp').reset_index(drop=True)

# Save to CSV
df.to_csv('synthetic_banking_transactions.csv', index=False)
print("Synthetic banking transaction data generated successfully!")
print(f"Number of transactions: {len(df)}")
print(f"Number of suspicious transactions: {df['is_suspicious'].sum()}")
print(df.head())