import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from faker import Faker # For generating realistic names

fake = Faker()

# --- Configuration for Customer Data ---
ACCOUNT_PREFIX = "ACC"
NUM_CUSTOMERS = 2500 # Number of unique customers
CUSTOMER_START_DATE = datetime(2010, 1, 1)
CUSTOMER_END_DATE = datetime(2023, 1, 1) # Customers onboarded before transaction data starts

OCCUPATIONS = [
    'Software Engineer', 'Teacher', 'Doctor', 'Nurse', 'Student', 'Unemployed',
    'Self-Employed Consultant', 'Retail Sales', 'Accountant', 'Lawyer',
    'Businessman', 'Government Employee', 'Real Estate Agent', 'Artist',
    'Chef', 'Scientist', 'Journalist', 'Pilot', 'Police Officer', 'Politician' # Add politician for PEP
]
NATIONALITIES = ['USA', 'UK', 'Canada', 'India', 'Germany', 'France', 'Australia', 'China', 'Brazil', 'Nigeria']
MARITAL_STATUSES = ['Single', 'Married', 'Divorced', 'Widowed']
SOURCE_OF_WEALTH = ['Employment', 'Investments', 'Inheritance', 'Business Profits', 'Savings', 'Real Estate Sales']
HOUSE_OWNERSHIP = ['Owned', 'Rented', 'Mortgaged']
RISK_CATEGORIES = ['Low', 'Medium', 'High']
ADD_NOISE = False
# Load the previously generated transaction data to get valid account IDs
try:
    df_transactions = pd.read_csv('synthetic_banking_transactions.csv')
    # Get all unique account IDs that have been senders or receivers
    all_account_ids = pd.concat([df_transactions['sender_account_id'], df_transactions['receiver_account_id']]).unique()
    # Filter out potential NaNs or non-string account IDs if any
    all_account_ids = [acc for acc in all_account_ids if isinstance(acc, str) and acc.startswith('ACC')]
    # Use only a subset of these for customer profiles, as not every account necessarily has a full profile
    # And some might be external bank accounts
    customer_account_ids = random.sample(all_account_ids, min(NUM_CUSTOMERS, len(all_account_ids)))
except FileNotFoundError:
    print("Warning: 'synthetic_banking_transactions_noisy.csv' not found. Generating generic account IDs.")
    customer_account_ids = [f"ACC{random.randint(1000000000, 9999999999)}" for _ in range(NUM_CUSTOMERS)]


# --- Helper Functions for Customer Data ---
def generate_customer_id(i):
    return f"CUST{i + 1:05d}"

def generate_dob():
    return fake.date_of_birth(minimum_age=18, maximum_age=90)

def generate_income(occupation):
    if occupation == 'Software Engineer': return random.randint(70000, 150000)
    elif occupation == 'Doctor': return random.randint(100000, 300000)
    elif occupation == 'Lawyer': return random.randint(80000, 250000)
    elif occupation == 'Businessman': return random.randint(50000, 500000)
    elif occupation == 'Politician': return random.randint(100000, 1000000) # Higher range for PEP
    elif occupation == 'Unemployed': return random.randint(0, 15000)
    elif 'Self-Employed' in occupation: return random.randint(30000, 150000)
    else: return random.randint(25000, 100000) # Default for others

def generate_credit_score(income):
    if income > 100000: return random.randint(700, 850)
    elif income > 50000: return random.randint(600, 750)
    else: return random.randint(300, 650)

def introduce_typo(text):
    if not isinstance(text, str) or len(text) < 3:
        return text
    idx = random.randint(0, len(text) - 1)
    if random.random() < 0.5: # Delete a character
        return text[:idx] + text[idx+1:]
    else: # Swap two characters
        if idx + 1 < len(text):
            return text[:idx] + text[idx+1] + text[idx] + text[idx+2:]
        else:
            return text[:idx-1] + text[idx] + text[idx-1] # Swap last two

def generate_account_id():
    return f"{ACCOUNT_PREFIX}{random.randint(1000000000, 9999999999)}"

def generate_timestamp(start, end):
    return start + (end - start) * random.random()

def generate_amount(min_val, max_val, decimal_places=2):
    return round(random.uniform(min_val, max_val), decimal_places)

# --- Generate Customer Data ---
customer_data = []

for i in range(NUM_CUSTOMERS):
    customer_id = generate_customer_id(i)
    account_id = customer_account_ids[i] if i < len(customer_account_ids) else f"ACC{random.randint(1000000000, 9999999999)}" # Fallback

    full_name = fake.name()
    date_of_birth = generate_dob()
    gender = random.choice(['Male', 'Female', 'Non-binary'])
    nationality = random.choice(NATIONALITIES)
    residence_country = nationality # For simplicity, residence is same as nationality
    occupation = random.choice(OCCUPATIONS)
    marital_status = random.choice(MARITAL_STATUSES)
    number_of_children = random.randint(0, 4)
    annual_income_usd = generate_income(occupation)
    source_of_wealth = random.choice(SOURCE_OF_WEALTH)
    house_ownership = random.choice(HOUSE_OWNERSHIP)
    credit_score = generate_credit_score(annual_income_usd)
    customer_since = generate_timestamp(CUSTOMER_START_DATE, CUSTOMER_END_DATE).date()

    # Heuristic for Risk Category (simplified)
    risk_category = 'Low'
    if annual_income_usd >= 200000 or 'Businessman' in occupation or 'Consultant' in occupation:
        risk_category = 'Medium'
    if annual_income_usd >= 500000 or 'Politician' in occupation:
        risk_category = 'High'
    if 'Unemployed' in occupation and annual_income_usd > 20000: # Unemployed with unexplained income
        risk_category = 'High'

    # PEP Status (inject a few)
    pep_status = False
    if occupation == 'Politician' or random.random() < 0.005: # 0.5% chance for others
        pep_status = True
        risk_category = 'High' # PEPs are inherently high risk

    # Sanction Status (inject a very few)
    sanction_status = False
    if random.random() < 0.001: # 0.1% chance
        sanction_status = True
        risk_category = 'High' # Sanctioned individuals are highest risk

    customer_data.append([
        customer_id, account_id, full_name, date_of_birth, gender, nationality,
        residence_country, occupation, marital_status, number_of_children,
        annual_income_usd, source_of_wealth, house_ownership, credit_score,
        customer_since, risk_category, pep_status, sanction_status
    ])

# Create DataFrame
df_customers = pd.DataFrame(customer_data, columns=[
    'customer_id', 'account_id', 'full_name', 'date_of_birth', 'gender', 'nationality',
    'residence_country', 'occupation', 'marital_status', 'number_of_children',
    'annual_income_usd', 'source_of_wealth', 'house_ownership', 'credit_score',
    'customer_since', 'risk_category', 'pep_status', 'sanction_status'
])

if ADD_NOISE:
    # --- Add some noise to customer data ---
    print("Adding noise to customer data...")

    # 1. Missing Values
    df_customers.loc[df_customers.sample(frac=0.03).index, 'occupation'] = np.nan
    df_customers.loc[df_customers.sample(frac=0.01).index, 'annual_income_usd'] = np.nan
    df_customers.loc[df_customers.sample(frac=0.02).index, 'credit_score'] = np.nan
    df_customers.loc[df_customers.sample(frac=0.01).index, 'nationality'] = np.nan

    # 2. Inconsistent Formatting / Typos
    df_customers['gender'] = df_customers['gender'].apply(lambda x: random.choice([x.lower(), x.upper()]) if random.random() < 0.05 else x)
    df_customers['occupation'] = df_customers['occupation'].apply(lambda x: introduce_typo(x) if pd.notna(x) and random.random() < 0.03 else x)
    df_customers['residence_country'] = df_customers['residence_country'].apply(lambda x: introduce_typo(x) if pd.notna(x) and random.random() < 0.02 else x)

    # 3. Outliers/Erroneous Data (e.g., extremely high children count, low credit score for high income)
    df_customers.loc[df_customers.sample(frac=0.005).index, 'number_of_children'] = random.choice([10, 15, 20])
    df_customers.loc[df_customers.sample(frac=0.002).index, 'annual_income_usd'] = random.choice([-5000, 10000000, 500]) # Unrealistic income
    df_customers.loc[df_customers.sample(frac=0.002).index, 'credit_score'] = random.choice([0, 100, 999]) # Unrealistic credit scores

# Save to CSV
df_customers.to_csv('synthetic_customer_data.csv', index=False)
print("\nSynthetic customer data with noise generated successfully!")
print(f"Number of customer profiles: {len(df_customers)}")
print(f"Number of PEPs: {df_customers['pep_status'].sum()}")
print(f"Number of Sanctioned individuals: {df_customers['sanction_status'].sum()}")
print("\nFirst 5 rows of the noisy customer dataset:")
print(df_customers.head())
print("\nInfo on the noisy customer dataset (check for NaNs, dtypes):")
print(df_customers.info())
print("\nValue counts for 'occupation' (check for inconsistencies):")
print(df_customers['occupation'].value_counts(dropna=False).head(10))
print("\nValue counts for 'gender' (check for casing):")
print(df_customers['gender'].value_counts(dropna=False))