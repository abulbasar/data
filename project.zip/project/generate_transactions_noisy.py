import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# --- Configuration ---
NUM_TRANSACTIONS = 15000 # Increased number for better noise distribution
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2023, 12, 31)
ACCOUNT_PREFIX = "ACC"
TRANSACTION_TYPES = ['Deposit', 'Withdrawal', 'Transfer', 'Online Purchase', 'Bill Payment', 'Loan Repayment']
CURRENCIES = ['USD', 'EUR', 'GBP', 'INR', 'CAD', 'AUD']
BANKS = ['Bank A', 'Bank B', 'Bank C', 'Global Bank Co.', 'Universal Fin.']
LOCATIONS_DOMESTIC = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Miami', 'Bengaluru', 'Mumbai', 'Delhi']
LOCATIONS_INTERNATIONAL_NORMAL = ['London', 'Paris', 'Berlin', 'Tokyo', 'Sydney', 'Toronto', 'Frankfurt', 'Rome']
LOCATIONS_INTERNATIONAL_RISK = ['Panama City', 'Cayman Islands', 'Zurich', 'Dubai', 'Singapore'] # Potential high-risk
ADD_NOISE = False


# --- Helper Functions ---
def generate_account_id():
    return f"{ACCOUNT_PREFIX}{random.randint(1000000000, 9999999999)}"

def generate_timestamp(start, end):
    return start + (end - start) * random.random()

def generate_amount(min_val, max_val, decimal_places=2):
    return round(random.uniform(min_val, max_val), decimal_places)

def introduce_typo(text):
    if not isinstance(text, str) or len(text) < 3:
        return text
    idx = random.randint(0, len(text) - 1)
    if random.random() < 0.5: # Delete a character
        return text[:idx] + text[idx+1:]
    else: # Swap two characters
        if idx + 1 < len(text):
            return text[:idx] + text[idx+1] + text[idx] + text[idx+2:]
        else:
            return text[:idx-1] + text[idx] + text[idx-1] # Swap last two

# --- Data Generation ---
data = []
account_pool = [generate_account_id() for _ in range(3000)] # Larger pool of accounts

for i in range(NUM_TRANSACTIONS):
    transaction_id = f"TXN{i + 1:07d}"
    timestamp = generate_timestamp(START_DATE, END_DATE)
    sender_account_id = random.choice(account_pool)
    receiver_account_id = random.choice(account_pool)
    while sender_account_id == receiver_account_id: # Ensure sender and receiver are different unless specifically for self-transfer
        receiver_account_id = random.choice(account_pool)

    transaction_type = random.choice(TRANSACTION_TYPES)
    amount = generate_amount(10, 50000) # General range

    currency = random.choice(CURRENCIES)
    sender_bank = random.choice(BANKS)
    receiver_bank = random.choice(BANKS)

    # Simulate location logic
    is_international = random.random() < 0.25 # 25% chance of international transaction
    if is_international:
        if random.random() < 0.15: # 15% of international are from 'risk' locations
            location = random.choice(LOCATIONS_INTERNATIONAL_RISK)
        else:
            location = random.choice(LOCATIONS_INTERNATIONAL_NORMAL)
    else:
        location = random.choice(LOCATIONS_DOMESTIC)

    transaction_purpose = f"Payment for {random.choice(['services', 'goods', 'investment', 'loan', 'family', 'salary', 'rent', 'utilities', 'consulting fees', 'travel', 'medical expenses'])}"

    # --- Injecting Suspicious Transactions (still for prototyping heuristic effectiveness) ---
    is_suspicious_flag = False # This flag is purely for data generation to create known suspicious examples

    if i % 70 == 0: # Large, round sum
        amount = random.choice([10000.00, 25000.00, 50000.00, 9999.99, 49999.99, 100000.00])
        transaction_type = 'Transfer'
        sender_bank = 'Global Bank Co.'
        receiver_bank = 'Bank A'
        location = random.choice(LOCATIONS_INTERNATIONAL_RISK)
        transaction_purpose = "Investment Transfer to Offshore Account"
        is_suspicious_flag = True
    elif i % 120 == 0: # Frequent small transactions just below threshold (e.g., $10k threshold)
        base_sender = sender_account_id # Keep sender consistent for structuring
        num_small_txns = random.randint(2, 5)
        for _ in range(num_small_txns):
            amount = generate_amount(9000, 9999) # Below threshold
            temp_timestamp = timestamp + timedelta(minutes=random.randint(1, 180)) # Within 3 hours
            # Vary receiver to simulate smurfing
            smurf_receiver = random.choice(account_pool)
            while smurf_receiver == base_sender: smurf_receiver = random.choice(account_pool)
            data.append([
                f"TXN_S{len(data)+1:07d}", temp_timestamp, base_sender,
                smurf_receiver, 'Deposit', amount, 'USD',
                sender_bank, 'Bank A', random.choice(LOCATIONS_DOMESTIC), 'Cash Deposit', True # Mark the individual smurf txns as suspicious
            ])
        amount = generate_amount(1000, 5000) # One regular txn to follow up
        is_suspicious_flag = True # Mark the original trigger as suspicious
    elif i % 180 == 0: # Unusual time and very large amount
        timestamp = generate_timestamp(datetime(2023,1,1,23,0,0), datetime(2023,12,31,5,0,0)) # Late night/early morning
        amount = generate_amount(75000, 200000)
        transaction_type = 'Transfer'
        is_suspicious_flag = True
    elif i % 220 == 0: # Rapid movement of funds (layering simulation)
        intermediary_account_1 = generate_account_id()
        intermediary_account_2 = generate_account_id()
        transfer_amount = generate_amount(15000, 30000)
        # Sender to intermediary 1
        data.append([
            f"TXN_L{len(data)+1:07d}", timestamp, sender_account_id, intermediary_account_1,
            'Transfer', transfer_amount, currency, sender_bank, 'Bank A', location, 'Layer 1', True
        ])
        # Intermediary 1 to intermediary 2
        data.append([
            f"TXN_L{len(data)+2:07d}", timestamp + timedelta(minutes=random.randint(5, 30)), intermediary_account_1, intermediary_account_2,
            'Transfer', transfer_amount * random.uniform(0.98, 1.02), currency, 'Bank A', 'Bank B', location, 'Layer 2', True
        ])
        # Intermediary 2 to final receiver
        data.append([
            f"TXN_L{len(data)+3:07d}", timestamp + timedelta(minutes=random.randint(35, 90)), intermediary_account_2, receiver_account_id,
            'Transfer', transfer_amount * random.uniform(0.95, 1.05), currency, 'Bank B', receiver_bank, location, 'Final Layer', True
        ])
        amount = generate_amount(1000, 5000) # Original transaction becomes a regular one
        is_suspicious_flag = True


    current_txn = [
        transaction_id, timestamp, sender_account_id, receiver_account_id,
        transaction_type, amount, currency, sender_bank, receiver_bank,
        location, transaction_purpose, is_suspicious_flag
    ]
    data.append(current_txn)

df = pd.DataFrame(data, columns=[
        'transaction_id', 'timestamp', 'sender_account_id', 'receiver_account_id',
        'transaction_type', 'amount', 'currency', 'sender_bank', 'receiver_bank',
        'location', 'transaction_purpose', 'is_suspicious'
    ])

if ADD_NOISE:
    # --- Introduce Noise ---
    print("Adding noise to the dataset...")

    # 1. Missing Values (NaNs)
    num_rows_to_corrupt = int(NUM_TRANSACTIONS * 0.02) # 2% of rows
    nan_indices = np.random.choice(df.index, num_rows_to_corrupt, replace=False)
    df.loc[nan_indices, 'amount'] = np.nan

    num_rows_to_corrupt = int(NUM_TRANSACTIONS * 0.01) # 1% of rows
    nan_indices = np.random.choice(df.index, num_rows_to_corrupt, replace=False)
    df.loc[nan_indices, 'transaction_type'] = np.nan

    num_rows_to_corrupt = int(NUM_TRANSACTIONS * 0.05) # 5% of rows
    nan_indices = np.random.choice(df.index, num_rows_to_corrupt, replace=False)
    df.loc[nan_indices, 'location'] = np.nan

    num_rows_to_corrupt = int(NUM_TRANSACTIONS * 0.15) # 15% of rows for purpose
    nan_indices = np.random.choice(df.index, num_rows_to_corrupt, replace=False)
    df.loc[nan_indices, 'transaction_purpose'] = np.nan

    # 2. Inconsistent Formatting
    # Currency casing
    df['currency'] = df['currency'].apply(lambda x: random.choice([x.lower(), x.upper(), x.capitalize()]) if pd.notna(x) and random.random() < 0.1 else x)
    # Transaction type variations/typos
    df['transaction_type'] = df['transaction_type'].apply(
        lambda x: random.choice([x, x.strip(), x.lower(), introduce_typo(x)]) if pd.notna(x) and random.random() < 0.08 else x
    )
    # Location typos
    df['location'] = df['location'].apply(
        lambda x: introduce_typo(x) if pd.notna(x) and random.random() < 0.05 else x
    )

    # 3. Outliers/Typographical Errors in Numeric Data (e.g., negative amounts, extremely large)
    num_outliers = int(NUM_TRANSACTIONS * 0.001) # 0.1%
    outlier_indices = np.random.choice(df.index, num_outliers, replace=False)
    df.loc[outlier_indices, 'amount'] = df.loc[outlier_indices, 'amount'].apply(
        lambda x: random.choice([-100, -500, 1000000, 5000000]) if pd.notna(x) else x
    )

    # 4. Duplicates
    num_duplicates_to_add = int(NUM_TRANSACTIONS * 0.01) # Add 1% duplicates
    duplicate_indices = np.random.choice(df.index, num_duplicates_to_add, replace=False)
    duplicate_rows = df.loc[duplicate_indices].copy()
    df = pd.concat([df, duplicate_rows], ignore_index=True)

    # 5. Inaccurate Data (Minor)
    # Assigning some 'dummy' account IDs to simulate internal test accounts or miscategorized ones
    dummy_account_ids = ['TEST_ACC_001', 'SUSP_ACC_999', 'BLOCKED_ACC_123']
    num_dummy_accounts = int(NUM_TRANSACTIONS * 0.005)
    dummy_indices = np.random.choice(df.index, num_dummy_accounts, replace=False)
    df.loc[dummy_indices, 'sender_account_id'] = np.random.choice(dummy_account_ids, num_dummy_accounts)
    df.loc[dummy_indices, 'receiver_account_id'] = np.random.choice(dummy_account_ids, num_dummy_accounts)

    # Add generic/empty purposes
    generic_purpose_indices = np.random.choice(df.index, int(NUM_TRANSACTIONS * 0.05), replace=False)
    df.loc[generic_purpose_indices, 'transaction_purpose'] = np.random.choice(['', 'Generic Payment', 'Misc.', 'Funds Transfer'], len(generic_purpose_indices))

    print("\nSynthetic banking transaction data with added noise generated successfully!")

# Sort by timestamp for better time-series analysis (this would be a pre-processing step)
df = df.sort_values(by='timestamp').reset_index(drop=True)

# Save to CSV
df.to_csv('synthetic_banking_transactions.csv', index=False)

print(f"Total number of transactions (including duplicates): {len(df)}")
print(f"Number of explicitly marked suspicious transactions (for validation): {df['is_suspicious'].sum()}")
print("\nFirst 5 rows of the noisy dataset:")
print(df.head())
print("\nInfo on the noisy dataset (check for NaNs, dtypes):")
print(df.info())
print("\nValue counts for 'transaction_type' (check for inconsistencies):")
print(df['transaction_type'].value_counts(dropna=False))
print("\nValue counts for 'currency' (check for casing):")
print(df['currency'].value_counts(dropna=False))